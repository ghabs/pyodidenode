char F2C_version[] = "20191129";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 20191129\n";
